<?php
$id_telegram = "6147313324";
$id_botTele  = "6297373003:AAFoP3R5v94yJgYzeOO5WfGy9pSx_nyVb_o";
?>
